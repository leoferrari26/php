<?php

namespace App\Controller;

use App\Entity\Categoria;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class CategoriaController extends AbstractController 
{
    /**
     * @Route("/categoria", name="categoria_index") 
    */ 
    public function index(EntityManagerInterface $em) :  Response 
    {
        //$em é objeto para auxiliar a execuçao de acoes no banco de dados
        $categoria = new Categoria();
        $categoria->setDescricaocategoria("Informática");
        $msg = "";

        try{
            $em->persist($categoria); //salvar em nivel de memoria
            $em->flush();// executa no banco de dados
            $msg="Cadastrado com sucesso!";

        } catch(Exception $em){

            $msg="Erro ao cadastrar";

        }

        return new Response("<h1>" . $msg . "</h1>");

    }

}