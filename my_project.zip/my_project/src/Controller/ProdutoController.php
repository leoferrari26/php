<?php 

namespace App\Controller;

use App\Entity\Produto;
use App\Repository\CategoriaRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ProdutoController extends AbstractController 
{
    /**
     * @Route("/produto", name="app_produto")
     */
    public function index(EntityManagerInterface $em , CategoriaRepository $categoriarepository) : Response 
    {
        $categoria = $categoriarepository->find(1); //1 é a categoria informatica
        $produto = new Produto();
        $produto->setNomeproduto('Notebook');
        $produto->setValor('3000');
        $produto->setCategoria($categoria);
        $msg="";

        try{
            $em->persist($produto); //salvar em nivel de memoria
            $em->flush();// executa no banco de dados
            $msg="Cadastrado com sucesso!";

        } catch(Exception $em){

            $msg="Erro ao cadastrar";

        }

        return new Response("<h1>" . $msg . "</h1>");

    }



}