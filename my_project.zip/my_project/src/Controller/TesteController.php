<?php 

namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;


class TesteController extends AbstractController 
{

    /**
     * @Route("/teste", name="app_teste")
     */

    public function index() : Response 
    {
        
        $data['mensagem'] = 'Entrou!';
        return $this->render('teste/index.html.twig', $data);

    }

}